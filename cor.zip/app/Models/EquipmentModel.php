<?php

namespace App\Models;

use CodeIgniter\Model;

class EquipmentModel extends Model
{

    protected $table      = 'equipment';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nolambung', 'status','waktu','driver', 'id_project'];

    public function getData()
    {
        $query= $this->db->query("SELECT * FROM equipment");
        return $query->getResult();
    }


}
