<div class="container-fluid">
    <h1><?php echo $title; ?></h1>
</div>